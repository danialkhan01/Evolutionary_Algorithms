# ACIT4610-Evolutionary-Algo
Project portfolio requirements


Provided are the four Evolutionary Algorithms that can be used to solve N-Queens problem.


1. Genetic Algorithm
2. Particle Swarm Optimisation
3. Artificial Immune System
4. Bees Algorithm
